This is my first HTML project
No styling, just markup and content
